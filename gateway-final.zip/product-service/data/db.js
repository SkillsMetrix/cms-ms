
const Product= require('../models/Product')

module.exports={
products: [
    new Product(1,  "laptop", 1000),
     new Product(2,  "mouse", 500)
  ]
}
