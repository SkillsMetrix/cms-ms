const express = require("express");

const router = express.Router();

const db = require("../data/db");

router.get("/", (req, res) => {
  res.json(db.products);
});
router.get("/loadpro", (req, res) => {
  res.send('all products loaded');
});

module.exports = router;
