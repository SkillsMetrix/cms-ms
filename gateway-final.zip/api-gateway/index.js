const express= require('express')
const {createProxyMiddleware}= require('http-proxy-middleware')
const path= require('path')
const fs= require('fs')

const app= express()

const routes= JSON.parse(fs.readFileSync(path.join(__dirname,'routes.json')))

for( const path in routes ){
    const target= routes[path]
    app.use(path,createProxyMiddleware({
        target
    }))
}

app.listen(3000,()=>{
    console.log('gateway started');
    
})