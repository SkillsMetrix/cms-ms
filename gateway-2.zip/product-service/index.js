
const express= require('express')

const app= express()

app.use(express.json())

 const products= [
    { id: 1, name: "soap", price: 1000 },
    { id: 2, name: "mouse", price: 400 },
  ]

  app.get('/products',(req,res)=> res.json(products))

app.listen(3002,()=> console.log('product service on 3002'))