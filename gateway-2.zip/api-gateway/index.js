


const express= require('express')
const {createProxyMiddleware}= require('http-proxy-middleware')

const app= express()

const routes={
    '/customers': 'http://localhost:3003/users',
    '/products': 'http://localhost:3002/products'
}

for( const route in routes ){
    const target= routes[route]
    app.use(route,createProxyMiddleware({target}))
}

app.listen(3001,()=>{
    console.log('gateway started');
    
})