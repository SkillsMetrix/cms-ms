module.exports = {
  users: [
    { id: 1, name: "Admin", email: "admin@mail.com" },
    { id: 2, name: "bob", email: "bob@mail.com" },
  ],
  products: [
    { id: 1, name: "laptop", price: 1000 },
    { id: 2, name: "Mouse", price: 500 },
  ],
  customers: [
    { id: 1, name: "charlie", address: "pune" },
    { id: 2, name: "Diana", address: "mumbai" },
  ],
};
