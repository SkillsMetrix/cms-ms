
const db= require('../data/db')


exports.getAllCustomers=() => db.customers;

exports.createCustomer=(customer)=>{
    customer.id=db.customers.length +1
    db.customers.push(customer)
    return customer
}