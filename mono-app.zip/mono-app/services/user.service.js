
const db= require('../data/db')


exports.getAllUsers=() => db.users;

exports.createUsers=(user)=>{
    user.id=db.users.length +1
    db.users.push(user)
    return user
}