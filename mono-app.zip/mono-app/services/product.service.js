
const db= require('../data/db')


exports.getAllProducts=() => db.products;

exports.createProducts=(product)=>{
    product.id=db.products.length +1
    db.products.push(product)
    return product
}