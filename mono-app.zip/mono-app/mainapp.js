
const express = require('express')

const app= express()
const PORT=3000


app.use(express.json())

const userRoutes= require('./routes/user.routes')
const customerRoutes= require('./routes/customer.routes')
const productRoutes= require('./routes/product.routes')


app.use('/users',userRoutes)
app.use('/products',productRoutes)
app.use('/customers',customerRoutes)


app.listen(PORT,()=>{
    console.log('server is ready...!');
    
})