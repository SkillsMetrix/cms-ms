
const ps = require("../services/product.service");

exports.getProducts = (req, res) => {
  res.json(ps.getAllProducts());
};
exports.addProduct = (req, res) => {
  const product = ps.createProducts(req.body);

  res.status(201).json(product);
};
