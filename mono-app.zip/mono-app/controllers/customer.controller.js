
const cs = require("../services/customer.service");

exports.getCustomers = (req, res) => {
  res.json(cs.getAllCustomers());
};
exports.addCustomer = (req, res) => {
  const customer = cs.createCustomer(req.body);

  res.status(201).json(customer);
};
