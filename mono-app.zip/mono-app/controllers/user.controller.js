
const us = require("../services/user.service");

exports.getusers = (req, res) => {
  res.json(us.getusers());
};
exports.addUser = (req, res) => {
  const user = us.createUsers(req.body);

  res.status(201).json(user);
};
