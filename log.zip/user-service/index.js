const express = require('express');
const logger = require('../shared/logger');
const tracer = require('../shared/tracer');
const zipkinMiddleware = require('zipkin-instrumentation-express').expressMiddleware;

const app = express();
app.use(zipkinMiddleware({ tracer }));

app.get('/user/profile', (req, res) => {
  logger.info('User profile called');
  res.json({ name: 'John Doe' });
});

app.listen(5000, () => {
  logger.info('User service running on port 5000');
});