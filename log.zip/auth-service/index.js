const express = require('express');
const logger = require('../shared/logger');
const tracer = require('../shared/tracer');
const zipkinMiddleware = require('zipkin-instrumentation-express').expressMiddleware;

const app = express();
app.use(zipkinMiddleware({ tracer }));

app.get('/auth/login', (req, res) => {
  logger.info('Auth login called');
  res.json({ message: 'User authenticated' });
});

app.listen(4000, () => {
  logger.info('Auth service running on port 4000');
});