const { Tracer, ExplicitContext, BatchRecorder } = require('zipkin');
const { HttpLogger } = require('zipkin-transport-http');

const ctxImpl = new ExplicitContext();
const recorder = new BatchRecorder({
  logger: new HttpLogger({
    endpoint: 'http://localhost:9411/api/v2/spans'
  })
});

const tracer = new Tracer({
  ctxImpl,
  recorder,
  localServiceName: 'node-service'
});

module.exports = tracer;
