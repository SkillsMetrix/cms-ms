const express = require('express');
const fs = require('fs');
const axios = require('axios');
const logger = require('../shared/logger');
const tracer = require('../shared/tracer');
const { expressMiddleware } = require('zipkin-instrumentation-express');

const app = express();
app.use(expressMiddleware({ tracer }));

const services = JSON.parse(fs.readFileSync('./service-registry/services.json', 'utf8'));

app.get('/login', async (req, res) => {
  try {
    const response = await axios.get(`${services['auth-service']}/auth/login`);
    res.json(response.data);
  } catch (error) {
    logger.error('Login failed', error.message);
    res.status(500).json({ message: 'Login error' });
  }
});

app.get('/profile', async (req, res) => {
  try {
    const response = await axios.get(`${services['user-service']}/user/profile`);
    res.json(response.data);
  } catch (error) {
    logger.error('Profile fetch failed', error.message);
    res.status(500).json({ message: 'Profile error' });
  }
});

app.listen(3000, () => {
  logger.info('API Gateway running on port 3000');
});