const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 4000;
const filePath = path.join(__dirname, 'services.json');

app.use(express.json());

// Load current services from file or empty
function loadServices() {
  try {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
  } catch {
    return {};
  }
}

// Save services to file
function saveServices(services) {
  fs.writeFileSync(filePath, JSON.stringify(services, null, 2));
}

// Register a new service
app.post('/register', (req, res) => {
  const { name, url } = req.body;
  const services = loadServices();
  services[name] = url;
  saveServices(services);
  res.json({ message: `Service ${name} registered at ${url}` });
});

// Get all services
app.get('/services', (req, res) => {
  const services = loadServices();
  res.json(services);
});

app.listen(PORT, () => console.log(`Registry service running on port ${PORT}`));
