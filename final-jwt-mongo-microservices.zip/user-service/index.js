const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const User = require('./models/User');
const loadConfig = require('./loadConfig');

const app = express();
app.use(bodyParser.json());


let jwtSecret;

const axios = require('axios');

async function registerWithRegistry(name, url) {
  try {
    await axios.post('http://localhost:4000/register', { name, url });
    console.log(`${name} registered with registry`);
  } catch (err) {
    console.error(`${name} failed to register:`, err.message);
  }
}


// Load Git-based config before starting service
loadConfig().then(config => {
  jwtSecret = config.jwtSecret;

  mongoose.connect(config.mongodb.uri)
    .then(() => console.log("MongoDB Atlas connected"))
    .catch(err => console.error("MongoDB connection error:", err));
        registerWithRegistry("user-service", "http://localhost:3001");

}).catch(err => {
  console.error("Fatal error: Failed to start service due to config error");
  process.exit(1);
});



// Register
app.post('/register', async (req, res, next) => {
  try {
    const { username, email, password } = req.body;
    const hash = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hash });
    await user.save();
    res.status(201).json({ message: 'User registered' });
  } catch (err) {
    next(err);
  }
});

// Profile (you’ll secure this via gateway with JWT later)
app.get('/profile', async (req, res, next) => {
  try {
    const user = await User.findOne({ username: req.user?.username });
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ username: user.username, email: user.email });
  } catch (err) {
    next(err);
  }
});

// Error handler
app.use((err, req, res, next) => {
  console.error("User error:", err);
  if (err.code === 11000) return res.status(409).json({ message: 'Duplicate user/email' });
  res.status(500).json({ message: 'Internal Server Error', error: err.message });
});

app.listen(3001, () => console.log("User service running on port 3001"));
