const express = require('express');
const axios = require('axios');
const CircuitBreaker = require('opossum');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');
const loadConfig = require('./loadConfig');

const app = express();
app.use(bodyParser.json());

let jwtSecret = '';
let serviceUrls = {};
let breakers = {};

const registryPath = path.join(__dirname, '../registry-service/services.json');

// ✅ Load service registry from services.json
function loadServiceRegistry() {
  try {
    if (!fs.existsSync(registryPath)) {
      console.warn("⚠️ services.json not found. Creating an empty file.");
      fs.writeFileSync(registryPath, JSON.stringify({}, null, 2));
    }
    const data = fs.readFileSync(registryPath);
    return JSON.parse(data);
  } catch (err) {
    console.error("❌ Failed to read services.json:", err.message);
    return {};
  }
}

// ✅ Create circuit breaker for each service
function createBreaker(baseUrl, name) {
  const breaker = new CircuitBreaker(
    (req) =>
      axios({
        method: req.method,
        url: baseUrl + req.url,
        headers: req.headers,
        data: req.body,
      }),
    {
      timeout: 5000,
      errorThresholdPercentage: 50,
      resetTimeout: 10000,
    }
  );

  breaker.fallback(() => ({
    status: 503,
    data: { message: `${name} is unavailable (circuit open)` },
  }));

  return breaker;
}

// ✅ Load config & initialize breakers
loadConfig()
  .then((config) => {
    jwtSecret = config.jwtSecret;
    console.log("✅ JWT secret loaded from config");

    serviceUrls = loadServiceRegistry();
    console.log("✅ Loaded services:", serviceUrls);

    // Setup breakers
    for (const [name, url] of Object.entries(serviceUrls)) {
      breakers[name] = createBreaker(url, name);
      console.log(`🔌 Circuit breaker ready for ${name} → ${url}`);
    }
  })
  .catch((err) => {
    console.error("❌ Failed to load config:", err.message);
    process.exit(1);
  });

// ✅ Public route: login → auth-service
app.post('/login', async (req, res) => {
  const authUrl = serviceUrls['auth-service'];
  if (!authUrl || !breakers['auth-service']) {
    return res.status(503).json({ message: "Auth service unavailable" });
  }

  try {
    const response = await breakers['auth-service'].fire(req);
    res.status(response.status).send(response.data);
  } catch (err) {
    res.status(err.status || 500).send(err.data || { message: 'Login failed via gateway' });
  }
});

// ✅ JWT Middleware for protected routes
function authenticateJWT(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ message: 'Missing token' });

  const token = authHeader.split(' ')[1];
  jwt.verify(token, jwtSecret, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid token' });
    req.user = user;
    next();
  });
}

// ✅ Protected route: /users/** → user-service
app.use('/users', authenticateJWT, async (req, res) => {
  const userUrl = serviceUrls['user-service'];
  if (!userUrl || !breakers['user-service']) {
    return res.status(503).json({ message: "User service unavailable" });
  }

  try {
    const response = await breakers['user-service'].fire(req);
    res.status(response.status).send(response.data);
  } catch (err) {
    res.status(err.status || 500).send(err.data || { message: 'User service error via gateway' });
  }
});

app.listen(3000, () => {
  console.log("🚀 API Gateway running at http://localhost:3000");
});
