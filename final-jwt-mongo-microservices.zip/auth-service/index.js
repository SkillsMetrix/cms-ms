const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const User = require('./models/User');
const loadConfig = require('./loadConfig');
const axios = require('axios');



const app = express();
app.use(bodyParser.json());

async function registerWithRegistry(name, url) {
  try {
    await axios.post('http://localhost:4000/register', { name, url });
    console.log(`${name} registered with registry`);
  } catch (err) {
    console.error(`${name} failed to register:`, err.message);
  }
}

let jwtSecret;

// Load Git-based config before starting service
loadConfig().then(config => {
  jwtSecret = config.jwtSecret;

  mongoose.connect(config.mongodb.uri)
    .then(() => console.log("MongoDB Atlas connected"))
    
    .catch(err => console.error("MongoDB connection error:", err));
    registerWithRegistry("auth-service", "http://localhost:3004");

}).catch(err => {
  console.error("Fatal error: Failed to start service due to config error");
  process.exit(1);
});

app.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    const token = jwt.sign({ username: user.username, role: user.role }, jwtSecret, { expiresIn: '1h' });
    res.json({ token });
  } catch (err) {
    next(err);
  }
});

app.use((err, req, res, next) => {
  console.error("Auth error:", err);
  res.status(500).json({ message: 'Internal Server Error', error: err.message });
});

app.listen(3004, () => console.log("Auth service running on port 3004"));
