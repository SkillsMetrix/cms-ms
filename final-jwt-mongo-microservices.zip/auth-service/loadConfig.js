// loadConfig.js
const axios = require('axios');

// Git raw config URL (replace with your GitHub raw link)
const CONFIG_URL = 'https://raw.githubusercontent.com/SkillsMetrix/config-server/main/config.json';

let configCache = null;

async function loadConfig() {
  if (configCache) return configCache; // use cached config

  try {
    const response = await axios.get(CONFIG_URL);
    configCache = response.data;
    return configCache;
  } catch (err) {
    console.error('Failed to load config from Git:', err.message);
    throw new Error('Configuration unavailable');
  }
}

module.exports = loadConfig;
