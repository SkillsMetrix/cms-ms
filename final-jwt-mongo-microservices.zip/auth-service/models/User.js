// MongoDB User model
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: { type: String, unique: true },
  password: String,
  email: { type: String, unique: true },
  role: { type: String, default: 'user' }
});

module.exports = mongoose.model('User', UserSchema);
