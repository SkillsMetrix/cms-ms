const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const path = require("path");

const fs = require("fs");

const app = express();

const routes = JSON.parse(fs.readFileSync(path.join(__dirname, "routes.json")));

for (const path in routes) {
  const target = routes[path];
  app.use(
    path,
    createProxyMiddleware({
      target,
      changeOrigin: true,
       onError: (err, req, res) => {
      console.error(`[Gateway Proxy Error] ${err.message}`);
      res.writeHead(500, {
        'Content-Type': 'application/json'
      });
      res.end(JSON.stringify({
        status: 500,
        message: 'Service temporarily unavailable',
        error: err.message
      }));
    }
    })
  );
}

app.use((req, res, next) => {
  console.log(`[Gateway] ${req.method} ${req.url}`);
  next();
});
app.use((err, req, res, next) => {
  console.error('[Gateway Exception]', err);
  res.status(err.status || 500).json({
    status: err.status || 500,
    message: err.message || 'Internal Server Error in API Gateway'
  });
});

app.listen(3000, () => console.log("API Gateway running on port 3000"));
