const axios= require('axios')

const CONFIG_URL='https://raw.githubusercontent.com/SkillsMetrix/config-server/main/config.json'

let configCache=null

async function loadConfig(){
    if(configCache) return configCache

    try{
        const response= await axios.get(CONFIG_URL)
        configCache= response.data
        return configCache
    }catch(err){
        console.error('Failed to load', err.message)
        throw new Error('configuration Unavailable')
    }
}
module.exports= loadConfig