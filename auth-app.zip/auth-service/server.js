
const express= require('express')
const jwt= require('jsonwebtoken')
const bodyParser= require('body-parser')
const app= express()
const PORT= 3004


const JWT_SECRET= 'supersecretkey'

app.use(bodyParser.json())

app.post('/login',(req,res)=>{
    const {username,password}=req.body
    if(username ==='admin' && password ==='password'){
        const token= jwt.sign({username},JWT_SECRET,{expiresIn: '1h'})
        return res.json({token})
    }
    res.status(401).json({error: 'Invalid credentials'})
})
app.listen(PORT,()=>{
    console.log('AUTH APP is ready');
    
})