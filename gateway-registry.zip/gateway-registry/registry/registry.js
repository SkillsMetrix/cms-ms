//load registry
// save registry
//expose the URL

const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(express.json());

const registryPath = path.resolve(__dirname, 'registry.json');

const loadRegistry = () => {
  if (!fs.existsSync(registryPath)) return {};
  return JSON.parse(fs.readFileSync(registryPath, 'utf-8'));
};

const saveRegistry = (data) => {
  fs.writeFileSync(registryPath, JSON.stringify(data, null, 2));
};

app.post('/register', (req, res) => {
  const { serviceName, host, port, basePath } = req.body;
  if (!serviceName || !host || !port || !basePath) {
    return res.status(400).json({ message: 'Missing required fields' });
  }
  const registry = loadRegistry();
  registry[serviceName] = { host, port, basePath };
  saveRegistry(registry);
  console.log(`✅ Registered: ${serviceName}`);
  res.json({ message: `${serviceName} registered` });
});

app.listen(5001, () => console.log('📘 Registry running on http://localhost:5001'));