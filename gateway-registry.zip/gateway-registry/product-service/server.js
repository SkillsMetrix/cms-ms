
const express= require('express')
const axios= require('axios')
const app= express()
const PORT= 3002
const register= async() =>{
    try{
        await axios.post('http://localhost:5001/register',{
            serviceName: 'product-service',
            host: 'localhost',
            port: PORT,
            basePath: '/products'
        })
        console.log(' product-service Registerd');
        
    }catch(err){
        console.error('Failed to register')
    }
}
app.use('/',(req,res)=>{
    res.send('welcome to product Data')
})

app.listen(3002,()=> {

    console.log('user service on 3002')
    register()
})