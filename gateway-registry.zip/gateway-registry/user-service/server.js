
const express= require('express')
const axios= require('axios')
const app= express()
const PORT= 3001
const register= async() =>{
    try{
        await axios.post('http://localhost:5001/register',{
            serviceName: 'user-service',
            host: 'localhost',
            port: PORT,
            basePath: '/users'
        })
        console.log(' user-service Registerd');
        
    }catch(err){
        console.error('Failed to register')
    }
}
app.use('/',(req,res)=>{
    res.send('welcome to User Data')
})

app.listen(3001,()=> {

    console.log('user service on 3001')
    register()
})